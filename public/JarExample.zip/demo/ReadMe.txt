write the test case in TestCase.java
do not modify TestCase.java className and execute method
write the test case function code in public String execute(String filePath, Map<String, String> context)
you can introduce jar in pom.xml, pls do not introduce too much jar, the jar must less than 10M.
after maven install, the demo-0.0.1-SNAPSHOT-jar-with-dependencies.jar is the jar you can use to upload to atp.