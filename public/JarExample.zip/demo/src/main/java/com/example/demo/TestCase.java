package com.example.demo;

import java.util.Map;

/**
 * Test Case, pls do not modify class name.
 *
 */
public class TestCase {


    /**
     * test case function code
     * 
     * @param filePath csar file path
     * @param context context info
     * @return execute result,success or fail reason
     */
    public String execute(String filePath, Map<String, String> context) {
        // TODO write your function code here
        return "success";
    }
}
